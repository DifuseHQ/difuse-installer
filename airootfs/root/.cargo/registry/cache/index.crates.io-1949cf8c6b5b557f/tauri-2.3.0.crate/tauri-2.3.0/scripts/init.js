// Copyright 2019-2024 Tauri Programme within The Commons Conservancy
// SPDX-License-Identifier: Apache-2.0
// SPDX-License-Identifier: MIT

;(function () {
  __RAW_freeze_prototype__

  __RAW_pattern_script__

  __RAW_ipc_script__

  __RAW_core_script__

  __RAW_event_initialization_script__

  __RAW_bundle_script__
})()
